// Fade-in effect for cards on scroll
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.card');
  
    const revealCards = () => {
      cards.forEach(card => {
        const rect = card.getBoundingClientRect();
        if (rect.top < window.innerHeight - 50) {
          card.classList.add('fade-in');
        }
      });
    };
  
    window.addEventListener('scroll', revealCards);
    revealCards(); // Run on page load as well
  });
  