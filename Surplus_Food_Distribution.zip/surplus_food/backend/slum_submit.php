<?php
include 'db.php';

$name = $_POST['area_name'];
$population = $_POST['population'];
$location = $_POST['location'];
$address = $_POST['address'];
$city = $_POST['city'];

$sql = "INSERT INTO slum_areas (area_name, population, location, address, city)
        VALUES ('$name', '$population', '$location', '$address', '$city')";

if ($conn->query($sql) === TRUE) {
    echo "Slum Area Details Submitted!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
