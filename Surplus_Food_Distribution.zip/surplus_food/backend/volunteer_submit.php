<?php
include 'db.php';

$name = $_POST['name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$address = $_POST['address'];
$city = $_POST['city'];

$sql = "INSERT INTO volunteers (name, email, contact, address, city)
        VALUES ('$name', '$email', '$contact', '$address', '$city')";

if ($conn->query($sql) === TRUE) {
    echo "Volunteer Registered Successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
