<?php
include 'db.php';

$food_name = $_POST['food_name'];
$quantity = $_POST['quantity'];
$location = $_POST['pickup_location'];
$contact = $_POST['contact'];

$sql = "INSERT INTO surplus_food (food_name, quantity, pickup_location, contact_number)
        VALUES ('$food_name', '$quantity', '$location', '$contact')";

if ($conn->query($sql) === TRUE) {
    echo "Surplus Food Reported!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
