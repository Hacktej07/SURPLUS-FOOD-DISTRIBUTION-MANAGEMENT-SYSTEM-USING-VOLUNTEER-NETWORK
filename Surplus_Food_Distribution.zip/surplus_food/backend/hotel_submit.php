<?php
include 'db.php';

$name = $_POST['hotel_name'];
$email = $_POST['email'];
$contact = $_POST['contact'];
$license = $_POST['license'];
$address = $_POST['address'];
$city = $_POST['city'];

$sql = "INSERT INTO hotels (hotel_name, email, contact, license, address, city)
        VALUES ('$name', '$email', '$contact', '$license', '$address', '$city')";

if ($conn->query($sql) === TRUE) {
    echo "Hotel Registered Successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
