<?php
$to = $_POST['email'];
$subject = "Thank you for registering!";
$message = "Welcome! Thank you for joining the fight against hunger.";
$headers = "From: noreply@surplusfood.com";

if (mail($to, $subject, $message, $headers)) {
    echo "Notification sent!";
} else {
    echo "Failed to send email.";
}
?>
